<template>
  <div id="visa">
    <h1>Sample App</h1>
    <form>
      <label for="first name">Enter text :</label>
      <input type="text" v-model="fName" required><p>Uppercase :  {{ fName.toUpperCase()}}</p>
    </form>
</div>
</template>

<script>
export default {
  name: 'Test',
  props: {
    msg: String
  },
  data(){
    return {
      fName: ''
    }
  }
}
</script>



<style scoped>
#visa {
  margin: 20px auto;
  max-width: 700px;
}
label{
  display: block;
  margin: 20px 0 10px;
}
input {
  font-size: 30px;
  border: 1px double rgb(102, 97, 96) ;
  border-radius: 4px;
}
</style>